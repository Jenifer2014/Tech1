module Openkey_Techno {
	
}