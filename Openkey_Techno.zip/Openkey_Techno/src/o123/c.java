package o123;

public class c {

	public static void main(String[] args) {
		String name="Jenifer";
		
		for(int i=0;i<=name.length();i++)
		{
			char st=name.charAt(i);
			System.out.println(st);
		}

	}
}
