package IT_GURU;

import org.testng.annotations.Test;

public class Orderwith_priority {
  @Test(priority=0)
  public void first() {
	  System.out.println("First test case");
  }
  @Test (priority=1)
  public void Second() {
	  System.out.println("Second test case");
  }
  @Test (priority=2)
  public void Thirsd() {
	  System.out.println("Third test case");
  }
  @Test (priority=3)
  public void fourth() {
	  System.out.println("Fourth test case");
  }
}
