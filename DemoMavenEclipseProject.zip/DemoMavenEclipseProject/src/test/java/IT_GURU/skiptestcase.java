package IT_GURU;

import org.testng.annotations.Test;

public class skiptestcase {
  @Test (priority=0)
  public void aStartcar() {
	  System.out.println("Start car");
  }
  @Test(priority=-1)
  public void Firstgear() {
	  System.out.println("First gear");
  }
  
  @Test (priority=5,enabled=false)
  public void Musicon() {
	  System.out.println("Turn on music");
  }
  
  @Test (priority=0)
  public void bSecondgear() {
	  System.out.println("Secong gear");
  }
  @Test (priority=0)
  public void thirdgear() {
	  System.out.println("Third gear");
  }
  @Test (priority=4)
  public void Fourthtgear() {
	  System.out.println("Fourth gear");
  }
  
}
