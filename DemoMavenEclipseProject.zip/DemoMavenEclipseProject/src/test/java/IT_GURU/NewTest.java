package IT_GURU;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class NewTest {
  @Test
  public void T1() {
	  System.out.println("I am Jenifer");
  }
  @Test
  public void T2()
  {
	  System.out.println("Welcome to Bangalore");
  }

}
