package IT_GURU;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class Openkey_onefitsall {
	ChromeDriver c;
  @Test
  public void Home_Page() throws InterruptedException {
	  Thread.sleep(3000);
		c.findElementByXPath("//*[@id=\'plazart-mainnav\']/div/div[2]/div/ul/li[1]/a").click();
		boolean b1=c.findElementByXPath("//*[@id=\'plazart-mainnav\']/div/div[2]/div/ul/li[1]/a").isDisplayed();
		
		if(b1)
		{
			System.out.println("Successful to Home Page");
			
		}
		else
		{
			System.out.println("Failed to home Page");
		}

  }
  @Test
  public void Aboutus_Page() throws InterruptedException {
	  Thread.sleep(3000);
		c.findElementByXPath("//*[@id=\'plazart-mainnav\']/div/div[2]/div/ul/li[2]/a").click();
		
		boolean b2=c.findElementByXPath("//*[@id=\'plazart-mainnav\']/div/div[2]/div/ul/li[2]/a").isDisplayed();
		
		if(b2)
		{
			System.out.println("Successful to about us Page");
		}
		else
		{
			System.out.println("Failed to about us Page");
		}
		
  }
 @Test
 public void contactus_page() throws InterruptedException {
	 Thread.sleep(3000);
	   c.findElementByXPath("//*[@id=\"plazart-mainnav\"]/div/div[2]/div/ul/li[7]/a").click();
	   c.findElementByXPath("//*[@id=\"jform_contact_name\"]").sendKeys("Jenifer");
	   boolean b3=c.findElementByXPath("//*[@id=\"jform_contact_name\"]").isDisplayed();
	  if(b3) 
	  {
		  System.out.println("Successful to Contact us Page");
	   }
	  else 
	  {
		  System.out.println("Failed to contact us Page");
	  }
 }
  @BeforeMethod
  public void beforeMethod() {
	  c.get("https://onenationfitsall.com/");
  }

  @AfterMethod
  public void afterMethod() throws IOException {
	
		  TakesScreenshot scrShot =((TakesScreenshot)c);

		     

	      File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

	  //Move image file to new destination
	      System.out.println("1st Random Number: " + Math.random());  
	     double s= Math.random();

	      File DestFile=new File("D:\\selenium\\screenshot\\"+"test12_"+s+".png");

	      //Copy file at destination

	     FileUtils.copyFile(SrcFile, DestFile);
	     
	      
	      System.out.println("screen shot is taken successfully");
	  }

  

  @BeforeClass
  public void beforeClass() {
	 
  }

  @AfterClass
  public void afterClass() throws IOException {
	  c.close();
  }

  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

  @BeforeSuite
  public void beforeSuite() {
	  System.setProperty("webdriver.chrome.driver","D:\\selenium\\drivers\\Chromedriver_103\\chromedriver_win32\\chromedriver.exe" );
	 
	  c=new ChromeDriver();
  }

  @AfterSuite
  public void afterSuite() {
  }

}
