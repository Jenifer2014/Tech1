package IT_GURU;


import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class Login_HRMS_TestNG {
ChromeDriver c;
@Test
  public void Admin() {
c.findElementByXPath("/html/body/div[1]/div[2]/ul/li[1]/a/b").click();

boolean b;
b = c.findElement(By.name("btnAdd")).isDisplayed();


if(b)
{
System.out.println("User can able to Add Employee ");
}
else
{
System.out.println("User is not able to Add Employee");
}
String ActualTitle = c.findElementByXPath("/html/body/div[1]/div[2]/ul/li[1]/a/b").getTagName();
System.out.println( ActualTitle);
String ExpectedTitle = "b";
Assert.assertEquals(ExpectedTitle, ActualTitle);
}

@Test
 public void Leave() {
c.findElementByXPath("//*[@id=\"menu_leave_viewLeaveModule\"]/b").click();

boolean b;
b = c.findElement(By.name("btnSearch")).isDisplayed();

if(b)
{
System.out.println("Leave has been verified successfully");
}
else
{
System.out.println("Leave has been not verified successfully");
}

}

@Test
 public void PIM() {
c.findElementByXPath("//*[@id=\"menu_pim_viewPimModule\"]/b").click();
String s= c.findElementByXPath("//*[@id=\"searchBtn\"]").getTagName();
System.out.println(s);
String ActualTitle = c.findElementByXPath("//*[@id=\"searchBtn\"]").getTagName();
System.out.println(ActualTitle);
String ExpectedTitle = "input";
Assert.assertEquals(ExpectedTitle, ActualTitle);
}



  @BeforeMethod
  public void beforeMethod() {
 c.get("https://opensource-demo.orangehrmlive.com/");
c.findElement(By.name("txtUsername")).sendKeys("Admin");
c.findElement(By.name("txtPassword")).sendKeys("admin123");
c.findElement(By.name("Submit")).click();

boolean b;
b  = c.findElementByXPath("//*[@id=\"menu_leave_viewLeaveModule\"]/b").isDisplayed();

if(b)
{
System.out.println("Logged in  successful");
}
else
{
System.out.println("Login is not happening");
}


}

 
  @AfterMethod
  public void afterMethod() throws Exception {
 TakesScreenshot scrShot =((TakesScreenshot) c);
      File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

           //Move image file to new destination
      System.out.println("1st Random Number: " + Math.random());  
     double n = Math.random();
      String name = "D:\\Selenium_Screens\\ " + "testNG" + n + " .png" ;

       File DestFile=new File(name);

               //Copy file at destination

       FileUtils.copyFile(SrcFile, DestFile);
               
               System.out.println("screen shot is taken successfully");

               //**************************************************************//
 c.findElement(By.id("welcome")).click();
 
Thread.sleep(4000);
//c.findElementByXPath("/html/body/div[1]/div[1]/div[10]/ul/li[3]/a").click();
c.findElementByXPath("//*[@id=\"welcome-menu\"]/ul/li[3]/a").click();
Thread.sleep(3000);

boolean b;
 b=c.findElement(By.name("Submit")).isDisplayed();

if(b)
{
System.out.println("Logout is successful");
}
else
{
System.out.println("Logout is NOT successful");
}
}

 

  @BeforeClass
  public void beforeClass() {
 c.get("https://opensource-demo.orangehrmlive.com/");
  }

  @AfterClass
  public void afterClass() {
 c.close();
  }

  @BeforeTest
  public void beforeTest() {
 System.out.println("Am before test");
  }

  @AfterTest
  public void afterTest()throws Exception{
 
 
  }

  @BeforeSuite
  public void beforeSuite() {
 System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver_win32_101 Version\\chromedriver.exe");
c=new ChromeDriver();
 System.out.println("Am before Suite");
  }

  @AfterSuite
  public void afterSuite() {
 System.out.println("Am after suite");
  }

}

