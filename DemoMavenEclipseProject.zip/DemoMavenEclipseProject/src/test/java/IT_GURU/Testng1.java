package IT_GURU;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class Testng1 {
	ChromeDriver c;
  @Test
  public void contact_Page() throws InterruptedException {
	  Thread.sleep(3000);
	   c.findElementByXPath("//*[@id=\"plazart-mainnav\"]/div/div[2]/div/ul/li[7]/a").click();
	   c.findElementByXPath("//*[@id=\"jform_contact_name\"]").sendKeys("Jenifer");
	   boolean b3=c.findElementByXPath("//*[@id=\"jform_contact_name\"]").isDisplayed();
	  if(b3) 
	  {
		  System.out.println("Successful to Contact us Page");
	   }
	  else 
	  {
		  System.out.println("Failed to contact us Page");
	  }
	  
  }
  @BeforeMethod
  public void beforeMethod() {
  }

  @AfterMethod
  public void afterMethod() {
  }

  @BeforeClass
  public void beforeClass() {
	  System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver_win32_101 Version\\chromedriver.exe" );
	  c=new ChromeDriver();
	  c.get("https://onenationfitsall.com/");
	  c.manage().window().maximize();
	  
  }

  @AfterClass
  public void afterClass() {
	  c.close();
  }

}
