package IT_GURU;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class Srinivas_TestNG {
	//Srinivas_TestNG s= new Srinivas_TestNG();
	ChromeDriver c ;
	public void screencapture1() throws IOException 
	  {
		 TakesScreenshot scrShot =((TakesScreenshot)c);

		     

		               File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

		           //Move image file to new destination
		               System.out.println("1st Random Number: " + Math.random());  
		              double s= Math.random();

		               File DestFile=new File("D:\\selenium\\screenshot\\"+"test12_"+s+".png");

		               //Copy file at destination

		               FileUtils.copyFile(SrcFile, DestFile);
		               
		               System.out.println("screen shot is taken successfully");
		}

	@Test
  public void f() {
  System.out.println("test annotation");
  c.findElementByXPath("//*[@id=\"menu_admin_viewAdminModule\"]/b").click();
  }
  
  @Test
  public void f1() throws IOException {
  System.out.println("test annotation1");
  c.findElementByXPath("//*[@id=\"menu_admin_viewPimModule\"]/b").click();
  screencapture1();
  
    }


@BeforeMethod
  public void beforeMethod() {
	  System.out.println("BeforeMethod annotation");  
	    c.get("https://opensource-demo.orangehrmlive.com/index.php/dashboard");
		c.findElementByName("txtUsername").sendKeys("Admin");
		c.findElementByName("txtPassword").sendKeys("admin123");
		c.findElementByName("Submit").click();
  }

  @AfterMethod
  public void afterMethod() throws InterruptedException {
	  System.out.println("AfterMethod annotation");
	  c.findElementById("welcome").click();
	  Thread.sleep(4000);
	  c.findElementByXPath("//*[@id=\"welcome-menu\"]/ul/li[3]/a").click();
  }

  

  @AfterClass
  public void afterClass() {
	  System.out.println("AfterClass annotation");
  }

  @BeforeTest
  public void beforeTest() {
	  System.out.println("BeforeTest annotation");
  }

  @AfterTest
  public void afterTest() {
	  System.out.println("AfterTest annotation");
  }

  @BeforeSuite
  public void beforeSuite() {
	  System.out.println("BeforeSuite annotation");
  }

  @AfterSuite
  public void afterSuite() {
	  System.out.println("AfterSuite annotation");
  }
  @BeforeClass
  public void beforeClass() {
	  System.out.println("BeforeClass annotation");
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\jenni\\OneDrive\\Desktop\\selenium_ide 5\\chromedriver_win32\\chromedriver.exe" );
	   c= new ChromeDriver();
  }
}
