package IT_GURU;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class NewTest1 {
	ChromeDriver c;
  @Test
  public void f() {
	  System.out.println("I am Test_PIM");
	  c.findElementByXPath("//*[@id=\"menu_pim_viewPimModule\"]/b").click();
		c.findElementByName("empsearch[employee_name][empName]").sendKeys("Jenifer");
		boolean b1 =c.findElementByName("empsearch[employee_name][empName]").isDisplayed();
		if(b1) {
			System.out.println("Pim opened sucessfully");
		}
		else {
			System.out.println("Pim opened Failled");
		}
  }
  @Test
  public void f1() {
	  System.out.println("I am Test1_Leave");
	  c.findElementByXPath("//*[@id=\"menu_leave_viewLeaveModule\"]/b").click();
		boolean b2 =c.findElementById("calFromDate").isDisplayed();
		if(b2) {
			System.out.println("Leave opened sucessfully");
		}
		else {
			System.out.println("Leave opened Failled");
		}
  }
  @Test
  public void f2() {
	  System.out.println("I am Test_Time");
	  c.findElementByXPath("//*[@id=\"menu_time_viewTimeModule\"]/b").click();
		boolean b3 =c.findElementById("employee").isDisplayed();
		if(b3) {
			System.out.println("Time opened sucessfully");
		}
		else {
			System.out.println("Time opened Failled");
		}
		}
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("I am Testing beforeMethod_Login");
	  c.get("https://opensource-demo.orangehrmlive.com/index.php/dashboard");
		c.findElementByName("txtUsername").sendKeys("Admin");
		c.findElementByName("txtPassword").sendKeys("admin123");
		c.findElementByName("Submit").click();
		boolean b =c.findElementByXPath("//*[@id=\"menu_admin_viewAdminModule\"]/b").isDisplayed();
		if(b) {
			System.out.println("login opened sucessfully");
		}
		else {
			System.out.println("login opened Failled");
		}
  }

  @AfterMethod
  public void afterMethod() throws Exception{
	  System.out.println("I am Testing afterMethod_Logot");
	  c.findElementById("welcome").click();
		Thread.sleep(4000);
		c.findElementByXPath("//*[@id=\"welcome-menu\"]/ul/li[3]/a").click();
  }

  @BeforeClass
  public void beforeClass() {
	  System.out.println("I am Testing beforeClass_Launch");
	  
	  System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver_win32_version100\\chromedriver.exe" );
	  c= new ChromeDriver();
  }

  @AfterClass
  public void afterClass() {
	  System.out.println("I am Testing afterClass_Closing Browser");
  }

  @BeforeTest
  public void beforeTest() {
	  System.out.println("I am Testing beforeTest");
	  
  }

  @AfterTest
  public void afterTest() {
	  System.out.println("I am Testing afterTest");
  }

  @BeforeSuite
  public void beforeSuite() {
	  System.out.println("I am Testing beforeSuite");
  }

  @AfterSuite
  public void afterSuite() {
	  System.out.println("I am Testing afterSuite");
  }

}
