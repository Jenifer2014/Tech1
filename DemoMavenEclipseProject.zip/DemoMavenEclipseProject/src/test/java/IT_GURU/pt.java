package IT_GURU;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class pt {
	ChromeDriver driver;
	
	@Test(priority=1)
	  public void Address_Page() throws InterruptedException {
	    Thread.sleep(3000); 
		driver.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[1]/ul/li/a/span[2]").click();
		Thread.sleep(3000);
		boolean b1=driver.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[1]/ul/li/a/span[2]").isDisplayed();
		if(b1)
	    {
	  	  System.out.println("Successful to Address Page");
	    }
	    else
	    {
	  	  System.out.println("Failed to Address Page"); 
	    }
	}
		 @Test(priority=2)
		 public void Facebook() throws InterruptedException {
		    Thread.sleep(3000); 
		    driver.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/div/a[1]/i").click();
		   
		    Thread.sleep(3000);
		    boolean b2=driver.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/div/a[1]/i").isDisplayed();
			if(b2)
		    {
		  	  System.out.println("Successful to Facebook Page");
		    }
		    else
		    {
		  	  System.out.println("Failed to Facebook Page"); 
		    }
		 }
		 @Test()
		  public void Instagram() throws InterruptedException {
		    Thread.sleep(3000); 
		    driver.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/div/a[2]/i").click();
		    boolean b3=driver.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/div/a[2]/i").isDisplayed();
			if(b3)
		    {
		  	  System.out.println("Successful to Instagram Page");
		    }
		    else
		    {
		  	  System.out.println("Failed to Instagram Page"); 
		    }
		 }
		    
		@Test()
		  public void Twitter() throws InterruptedException {
		    Thread.sleep(3000); 
		    driver.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/div/a[3]/i").click();
		    boolean b4=driver.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/div/a[2]/i").isDisplayed();
			if(b4)
		    {
		  	  System.out.println("Successful to Twitter Page");
		    }
		    else
		    {
		  	  System.out.println("Failed to Twitter Page"); 
		    }
		 }
  @BeforeClass
  public void beforeClass() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver_win32_101 Version\\chromedriver.exe" );
	  driver=new ChromeDriver();
	 
	  Thread.sleep(3000);
	  driver.get("https://watchrepairco.com/");
	  driver.manage().window().maximize();
	  
	  
  }

  @AfterClass
  public void afterClass() {
	  driver.close();
  }

}
