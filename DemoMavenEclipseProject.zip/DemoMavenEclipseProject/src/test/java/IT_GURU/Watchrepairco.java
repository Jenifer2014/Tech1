package IT_GURU;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class Watchrepairco {
	ChromeDriver c;
   @Test (priority=0)
  public void Location() throws InterruptedException 
  {
	  Thread.sleep(3000);
	 c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[1]/ul/li/a/span[1]").click();
      boolean b=c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[1]/ul/li/a/span[1]").isDisplayed();
	 if(b)
      {
    	  System.out.println("Successful to loction Page");
      }
      else
      {
    	  System.out.println("Failed to loction Page"); 
      }
  }
	 @Test(priority=1)
  public void Address_Page() throws InterruptedException {
    Thread.sleep(3000); 
	c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[1]/ul/li/a/span[2]").click();
	Thread.sleep(3000);
	boolean b1=c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[1]/ul/li/a/span[2]").isDisplayed();
	if(b1)
    {
  	  System.out.println("Successful to Address Page");
    }
    else
    {
  	  System.out.println("Failed to Address Page"); 
    }
}
	 @Test(priority=2)
	 public void Facebook() throws InterruptedException {
	    Thread.sleep(3000); 
	    c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/div/a[1]/i").click();
	   
	    Thread.sleep(3000);
	    boolean b2=c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/div/a[1]/i").isDisplayed();
		if(b2)
	    {
	  	  System.out.println("Successful to Facebook Page");
	    }
	    else
	    {
	  	  System.out.println("Failed to Facebook Page"); 
	    }
	 }
	 @Test(priority=3)
	  public void Instagram() throws InterruptedException {
	    Thread.sleep(3000); 
	    c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/div/a[2]/i").click();
	    boolean b3=c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/div/a[2]/i").isDisplayed();
		if(b3)
	    {
	  	  System.out.println("Successful to Instagram Page");
	    }
	    else
	    {
	  	  System.out.println("Failed to Instagram Page"); 
	    }
	 }
	    
	@Test(priority=4)
	  public void Twitter() throws InterruptedException {
	    Thread.sleep(3000); 
	    c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/div/a[3]/i").click();
	    boolean b4=c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/div/a[2]/i").isDisplayed();
		if(b4)
	    {
	  	  System.out.println("Successful to Twitter Page");
	    }
	    else
	    {
	  	  System.out.println("Failed to Twitter Page"); 
	    }
	 }
	@Test(priority=5)
	  public void Whatsapp() throws InterruptedException {
	    Thread.sleep(3000); 
	    c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/ul/li[2]/a/img").click();
	    boolean b5=c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/ul/li[2]/a/img").isDisplayed();
		if(b5)
	    {
	  	  System.out.println("Successful to Whatsapp Page");
	    }
	    else
	    {
	  	  System.out.println("Failed to whatsapp Page"); 
	    }
	 }
	 @Test(priority=6)
	  public void contact() throws InterruptedException {
	    Thread.sleep(3000); 
	    c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/ul/li[1]/a[2]").click();
	    Thread.sleep(3000); 
	    boolean b6=c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/ul/li[2]/a/img").isDisplayed();
		if(b6)
	    {
	  	  System.out.println("Successful to contact Page");
	    }
	    else
	    {
	  	  System.out.println("Failed to contact Page"); 
	    }
	 }
	@Test(priority=7)
	  public void Gmail() throws InterruptedException {
	    Thread.sleep(3000); 
	    c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/ul/li[3]/a[2]").click();
	    boolean b7=c.findElementByXPath("/html/body/div[8]/div/header/div/div/div/section[1]/div/div/div/div/div/section/div/div/div/div/div/div/div/header/div/div/div/div[2]/ul/li[2]/a/img").isDisplayed();
		if(b7)
	    {
	  	  System.out.println("Successful to Gmail Page");
	    }
	    else
	    {
	  	  System.out.println("Failed to Gmail Page"); 
	    }
		
	}
	@Test(priority=8)
	  public void AboutusPage() throws InterruptedException {
	    Thread.sleep(3000); 
	    c.findElementByXPath("//*[@id=\"menu-item-2252\"]/a/span").click();
	    Thread.sleep(3000); 
	    boolean b7=c.findElementByXPath("//*[@id=\"menu-item-2252\"]/a/span").isDisplayed();
		if(b7)
	    {
	  	  System.out.println("Successful to Aboutus Page");
	    }
	    else
	    {
	  	  System.out.println("Failed to Aboutus Page"); 
	    }
	}
	@Test(priority=9)
	  public void HomePage() throws InterruptedException {
	    Thread.sleep(3000); 
	    c.findElementByXPath("//*[@id=\"menu-item-2246\"]/a/span").click();
	    
	    boolean b8=c.findElementByXPath("//*[@id=\"menu-item-2246\"]/a/span").isDisplayed();
		if(b8)
	    {
	  	  System.out.println("Successful to Home Page");
	    }
	    else
	    {
	  	  System.out.println("Failed to Home Page"); 
	    }
	}
	@Test(priority=10)
	  public void ServicePage() throws InterruptedException {
	    Thread.sleep(3000); 
	    c.findElementByXPath("//*[@id=\"menu-item-3744\"]/a/span").click();
	    Thread.sleep(3000); 
	    boolean b9=c.findElementByXPath("//*[@id=\"menu-item-3744\"]/a/span").isDisplayed();
		if(b9)
	    {
	  	  System.out.println("Successful to Service Page");
	    }
	    else
	    {
	  	  System.out.println("Failed to Service Page"); 
	    }
	}
@BeforeClass
  public void beforeClass() throws InterruptedException {
	  Thread.sleep(3000);
	  c.get("https://watchrepairco.com/");
	  c.manage().window().maximize();
  }
  @BeforeMethod
  public void Beforemethod() {
  }
  @AfterMethod
  public void Aftermethod() throws IOException {
	 TakesScreenshot scrShot =((TakesScreenshot)c);

	     

      File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

  //Move image file to new destination
      System.out.println("1st Random Number: " + Math.random());  
     double s= Math.random();

     
      File DestFile=new File("D:\\selenium\\screenshot\\Watchrepairco"+"Watchrepair_"+s+".png");

      //Copy file at destination

      FileUtils.copyFile(SrcFile, DestFile);
      
      System.out.println("screen shot is taken successfully");
	  
  }
  @AfterClass
  public void afterClass() {
	  c.close();
  }

  @BeforeSuite
  public void beforeSuite() {
	  
	  System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver_win32_101 Version\\chromedriver.exe" );
	  c=new ChromeDriver();
  }

  @AfterSuite
  public void afterSuite() {
	  c.quit();
  }

}
