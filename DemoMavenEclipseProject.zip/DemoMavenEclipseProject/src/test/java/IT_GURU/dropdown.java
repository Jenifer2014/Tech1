package IT_GURU;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class dropdown {

	

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\jenni\\eclipse-workspace\\Cucumber1990_Project\\src\\test\\resources\\Drivers\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		
		driver.navigate().to("https://letcode.in/dropdowns");
		driver.manage().window().maximize();
		
		WebElement dropdowm=driver.findElementById("fruits");
		Select select=new Select(dropdowm);
		select.selectByIndex(2);
		 Thread.sleep(3000);
		select.selectByValue("3");
		 Thread.sleep(3000);
		select.selectByVisibleText("Pine Apple");
		
		List<WebElement>listofoptions =select.getOptions();
		int list=listofoptions.size();
		System.out.println("Size of list : "  +list);
		
		WebElement multiselect=driver.findElementById("superheros");
		Select ms=new Select(multiselect);
		ms.selectByValue("ta");
		ms.selectByVisibleText("Captain America");
		ms.selectByIndex(7);

	}

}
