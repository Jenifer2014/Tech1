package learning_Testng;

public interface ITestListeners {

}
