package learning_Testng;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class paralletest1 {
	WebDriver driver;
  @Test
  public void google() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver_win32_101 Version\\chromedriver.exe" );
	  driver=new ChromeDriver();
	  driver.get("http://google.com");
	  String title=driver.getCurrentUrl();
	  Thread.sleep(3000);
	   
  }
  public void gmail() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver_win32_101 Version\\chromedriver.exe" );
	  driver=new ChromeDriver();
	  driver.get("https://mail.google.com");
	  String title=driver.getCurrentUrl();
	  Thread.sleep(3000);
	   
  }
}
