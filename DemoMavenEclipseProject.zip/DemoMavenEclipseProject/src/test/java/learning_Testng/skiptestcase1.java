package learning_Testng;

import org.testng.annotations.Test;

public class skiptestcase1 {
	 @Test (priority=0)
	  public void Startcar() {
		  System.out.println("Start car");
	  }
	  @Test(priority=1,enabled=false)
	  public void Firstgear() {
		  System.out.println("First gear");
	  }
	  
	  @Test (priority=5,enabled=false)
	  public void Musicon() {
		  System.out.println("Turn on music");
	  }
	  
	  @Test (priority=2)
	  public void Secondgear() {
		  System.out.println("Secong gear");
	  }
	  @Test (priority=3)
	  public void thirdgear() {
		  System.out.println("Third gear");
	  }
	  @Test (priority=4)
	  public void Fourthtgear() {
		  System.out.println("Fourth gear");
	  }
}
