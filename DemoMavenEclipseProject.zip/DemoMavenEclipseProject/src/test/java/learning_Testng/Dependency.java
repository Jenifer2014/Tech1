package learning_Testng;

import org.testng.annotations.Test;

public class Dependency {
  @Test()
  public void High_school() {
	  System.out.println("High School");
  }
  
  @Test(priority=1,dependsOnMethods="High_school")
  public void Higher_Secondary_school() {
	  System.out.println("Higher Secondary School");
  }
  
  

  @Test(priority=2,dependsOnMethods="Higher_Secondary_school")
  public void College() {
	  System.out.println("College of Engineering");
  }
}
