package learning_Testng;

import org.testng.annotations.Test;

public class Timeout {
	@Test (timeOut = 1 )
	 public void testcase1()  
	 {  
	     System.out.println("testcase1 testcase1testcase1testcase1testcase1testcase1testcase1testcase1testcase1testcase1testcase1testcase1testcase1testcase1testcase1testcase1testcase1");  
	 }  
	
}
