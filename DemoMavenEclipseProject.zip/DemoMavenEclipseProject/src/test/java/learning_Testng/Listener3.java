package learning_Testng;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.Test;

public class Listener3 implements ITestListener {
  
	public void onStart(ITestContext context) {	
		System.out.println("onStart method started");
	}
	
	public void onFinish(ITestContext context) {
		System.out.println("onFinish method started");
	}
	
		public void onTestStart(ITestResult result) {
			System.out.println("New Test Started" +result.getName());
		}
	public void onTestSuccess(ITestContext context) {	
		System.out.println("onStart method Success");
	}
	
	public void onTestFailure(ITestContext context) {	
		System.out.println("onStart method failure");
		
	}
	
	public void onTestSkipped(ITestContext context) {	
		System.out.println("onStart method skipped");
		
	}
}
