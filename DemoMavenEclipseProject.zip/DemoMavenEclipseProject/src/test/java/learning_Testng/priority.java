package learning_Testng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

public class priority {
  @Test(priority=0)
  public void f() {
	  System.out.println("Welcome to Bangalore 1");
  }
  @Test(priority=1)
  public void a1() {
	  System.out.println("Welcome to Bangalore 2");
  }
  @Test(priority=2)
  public void c() {
	  System.out.println("Welcome to Bangalore 3");
  }
  @Test(priority=3)
  public void b () {
	  System.out.println("Welcome to Bangalore 4");
  }
  @BeforeClass
  public void beforeClass() {
	  System.out.println("I am Befeor class");
  }

  @AfterClass
  public void afterClass() {
	  System.out.println("I am Afterclass");
  }

}
