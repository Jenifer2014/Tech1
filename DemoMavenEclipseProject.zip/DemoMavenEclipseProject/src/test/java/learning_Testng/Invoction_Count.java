package learning_Testng;

import org.testng.annotations.Test;

public class Invoction_Count {
	@Test(invocationCount=10)  
	 public void testcase1()  
	 {  
	     System.out.println("testcase1");  
	 }  
}
