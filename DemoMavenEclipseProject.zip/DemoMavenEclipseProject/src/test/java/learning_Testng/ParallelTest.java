package learning_Testng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.*;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ParallelTest {
	public WebDriver driver;
		
        @Test
        public void FirefoxTest() {	 
            //Initializing the firefox driver (Gecko)
        	System.setProperty("webdriver.gecko.driver", "D:\\selenium\\geckodriver-v0.31.0-win64\\geckodriver.exe");
   		driver= new FirefoxDriver();	  
	    driver.get("https://onenationfitsall.com"); 
	   // driver.findElement(By.xpath("//*[@id=\'plazart-mainnav\']/div/div[2]/div/ul/li[1]/a")).click();
	    driver.quit();
         }
 
        
        @Test
 	public void ChromeTest()
 	{ 
	  //Initialize the chrome driver
        System.setProperty( "webdriver.chrome.driver","D:\\selenium\\chromedriver_win32_101 Version\\chromedriver.exe");
	  driver = new ChromeDriver();
	  driver.get("https://onenationfitsall.com"); 
	  //driver.findElement(By.xpath("//*[@id=\'plazart-mainnav\']/div/div[2]/div/ul/li[1]/a")).click();
	  driver.quit();
 	}
	/*
	 * @BeforeTest public void beforeTest() { System.setProperty(
	 * "webdriver.chrome.driver","D:\\selenium\\chromedriver_win32_101 Version\\chromedriver.exe"
	 * ); ChromeDriver driver=new ChromeDriver(); }
	 * 
	 * @AfterTest public void afterTest() {
	 * System.out.println("Closing the browser "); driver.close(); }
	 */
}
