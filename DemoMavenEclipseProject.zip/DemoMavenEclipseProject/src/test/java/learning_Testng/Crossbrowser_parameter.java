package learning_Testng;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Crossbrowser_parameter {
	public WebDriver driver;
	

	@Test
	public void amazon()
	{
		 driver.findElement(By.name("field-keywords")).sendKeys("Mobile"+Keys.ENTER);
		 
	}
	
	
	@Test
	public void amazon1()
	{
		driver.findElement(By.name("field-keywords")).clear();
		driver.findElement(By.name("field-keywords")).sendKeys("fan"+Keys.ENTER);
		
	
	}
		 @BeforeClass
		 @Parameters ("browser1")
		  public void beforeClass(String browser1) {
			 if(browser1.equalsIgnoreCase("chrome")) {
			 WebDriverManager.chromedriver().setup();
			  driver = new ChromeDriver();
			  
			 }
			 else if(browser1.equalsIgnoreCase("firefox"))
			  {
				  WebDriverManager.firefoxdriver().setup();
				  driver =new FirefoxDriver();
			  }
				/*
				 * else if(browser.equalsIgnoreCase("IE")) {
				 * WebDriverManager.iedriver().setup(); driver =new InternetExplorerDriver(); }
				 */
			  /*else if(browser.equalsIgnoreCase("edge"))
			  {
				  WebDriverManager.edgedriver().setup();;
				  driver =new EdgeDriver();
			  }*/
			  
			 driver.get("https://www.amazon.in");
			  driver.manage().window().maximize();
		  }
		 
		 @AfterClass
		  public void afterClass() {
			  driver.quit();
		  }

}
