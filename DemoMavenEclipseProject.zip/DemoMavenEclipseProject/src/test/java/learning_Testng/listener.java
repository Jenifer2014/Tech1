package learning_Testng;

import org.testng.ITestListener;
import org.testng.annotations.Test;

public class listener implements ITestListener {
  @Test
  public void f() {
  }
}
