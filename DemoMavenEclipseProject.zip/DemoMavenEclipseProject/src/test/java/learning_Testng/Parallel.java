package learning_Testng;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Parallel {
	WebDriver driver;
  @Test
  public void Opengoogle() {
	  System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver_win32_101 Version\\chromedriver.exe" );
	  ChromeDriver driver=new ChromeDriver();
	  driver.get("https://www.google.com");
	  
	  
	  
  }
  
  @Test
  public void Openbing() {
	  System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver_win32_101 Version\\chromedriver.exe" );
	  ChromeDriver driver=new ChromeDriver();
	  driver.get("https://www.bing.com");
	  
  }
}
