package learning_Testng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterClass;

public class Crossbowser12 {
	public WebDriver driver;
	@Test
	public void amazon()
	{
		 driver.findElement(By.name("field-keywords")).sendKeys("Mobile"+Keys.ENTER);
		
		 
	}
	
	
	@Test
	public void amazon1()
	{
		driver.findElement(By.name("field-keywords")).clear();
		driver.findElement(By.name("field-keywords")).sendKeys("fan"+Keys.ENTER);
	
	}
  @BeforeClass
  @Parameters("browser1")
  
	  public void beforeClass(String browser1) {
			 if(browser1.equalsIgnoreCase("chrome")) {
				 System.setProperty("webdriver.chrome.driver","D:\\selenium\\drivers\\Chromedriver_103\\chromedriver_win32\\chromedriver.exe" );
	  driver=new ChromeDriver();
	  }
			 else if(browser1.equalsIgnoreCase("firefox")) {
				 System.setProperty("webdriver.gecko.driver", "D:\\selenium\\geckodriver-v0.31.0-win64\\geckodriver.exe");
				 driver= new FirefoxDriver();
			 }
			 
			 
			 driver.get("https://www.amazon.in");
			  driver.manage().window().maximize();
  }

  @AfterClass
  public void afterClass() {
	  driver.quit();
  }

}
