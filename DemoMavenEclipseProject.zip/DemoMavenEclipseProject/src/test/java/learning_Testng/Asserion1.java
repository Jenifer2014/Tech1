package learning_Testng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class Asserion1 {
	ChromeDriver driver;
	@Test
	  public void Aboutus_Page() throws InterruptedException {
		  Thread.sleep(3000);
			driver.findElementByXPath("//*[@id=\'plazart-mainnav\']/div/div[2]/div/ul/li[2]/a").click();
			
			boolean b2=driver.findElementByXPath("//*[@id=\'plazart-mainnav\']/div/div[2]/div/ul/li[2]/a").isDisplayed();
			
			if(b2)
			{
				System.out.println("Successful to about us Page");
			}
			else
			{
				System.out.println("Failed to about us Page");
			}
			String title=driver.getTitle();
			System.out.println("Current Title : "+title);
		    Assert.assertEquals(title, "About Use");
	}
  @BeforeClass
  public void beforeClass() {
	  System.setProperty("webdriver.chrome.driver","D:\\selenium\\drivers\\Chromedriver_103\\chromedriver_win32\\chromedriver.exe" );
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().deleteAllCookies();
	  
	  driver.get("https://onenationfitsall.com/");
	  
  }

  @AfterClass
  public void afterClass() {
	  driver.close();
  }

}
