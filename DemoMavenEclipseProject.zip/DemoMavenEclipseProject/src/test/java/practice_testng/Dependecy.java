package practice_testng;

import org.testng.annotations.Test;

public class Dependecy {
  @Test(priority=0)
  public void High_school() 
  {
	  System.out.println("High School");
  }
  
  @Test(dependsOnMethods="High_School")
  public void Highersecondary_School() 
  {
	  System.out.println("Higher Secondary School");
  }
  
  @Test(dependsOnMethods="Highersecondary_School")
  public void college() 
  {
	  System.out.println("Engineering college");
  }
}
