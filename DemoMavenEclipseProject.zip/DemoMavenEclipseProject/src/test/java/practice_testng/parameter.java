package practice_testng;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.beust.jcommander.Parameter;


public class parameter {
	@Test
	  @Parameters("Name")
	  public void Parameter(String name) {
		  System.out.println("Name is "+name);
	  }
	  @Test
	  @Parameters("Name1")
	  public void Parameter1(String name1) {
		  System.out.println("Name is "+name1);
	  }
}