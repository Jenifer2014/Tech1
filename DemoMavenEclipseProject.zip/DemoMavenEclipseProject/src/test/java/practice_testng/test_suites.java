package practice_testng;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class test_suites {
	ChromeDriver c;
	long EndTime;
	long StartTime;
	@BeforeSuite
	public void Launch_Browser() 
	{
		StartTime=System.currentTimeMillis();
		System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver_win32_101 Version\\chromedriver.exe" );
		  c=new ChromeDriver();
	}
  @Test
  public void opengoogle() 
  {
	  c.get("http://google.com");
	    
  }
  @Test
  public void openbing() 
  {
	  c.get("http://bing.com");
  }
  @Test
  public void openyahoo() 
  {
	  c.get("http://yahoo.com"); 
  }
  @AfterSuite
  public void CloseBrowser() 
  {
	  c.quit();
	   EndTime=System.currentTimeMillis();
	  long TotalTime=EndTime-StartTime;
	  System.out.println("Total Time Taken:"+TotalTime);
  }
 
}
