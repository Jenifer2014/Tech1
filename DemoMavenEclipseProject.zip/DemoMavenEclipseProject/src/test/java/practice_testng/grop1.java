package practice_testng;

import org.testng.annotations.Test;

public class grop1 {
  @Test (groups= {"Apple"})
  public void apple() {
	  System.out.println("I am Apple");
  }
  @Test (groups= {"Apple"})
  public void Greenapple() {
	  System.out.println("I am greenApple");  
  }
  @Test (groups= {"Apple"})
  public void Kashmirapple() {
	  System.out.println("I am kashmirApple");
}
  @Test (groups= {"Orange"})
  public void orange() {
	  System.out.println("I am orange");
}
  @Test (groups= {"Orange"})
  public void kamalaorange() {
	  System.out.println("I am kamalaorange");
} 
  @Test (groups= {"Orange"})
  public void highbridorange() {
	  System.out.println("I am highbirdorange");
}
  @Test (groups= {"Banana"})
  public void banana() {
	  System.out.println("I am banana");
}
  @Test (groups= {"Banana"})
  public void yellakibanana() {
	  System.out.println("I am yellakibanana");
}
   
  @Test (groups= {"Banana"})
  public void rawbanana() {
	  System.out.println("I am rawbanana");
}
  @Test (groups= {"Lemon"})
  public void lemon() {
	  System.out.println("I am lemon");
}
  @Test (groups= {"Lemon"})
  public void biglemon() {
	  System.out.println("I am biglemon");
}
}