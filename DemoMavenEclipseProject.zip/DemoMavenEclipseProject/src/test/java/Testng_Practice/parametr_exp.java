package Testng_Practice;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class parametr_exp {
  @Test
  @Parameters("Name4")
  public void uname(String string) {
	  System.out.println("User Name:" +string);
  }
  @Test
  @Parameters("Name7")
  public void uname1(String string1) {
	  System.out.println("User Name:" +string1);
  }
}
