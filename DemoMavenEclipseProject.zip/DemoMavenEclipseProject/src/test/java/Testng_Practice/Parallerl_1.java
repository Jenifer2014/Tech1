package Testng_Practice;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Parallerl_1 {
  @Test
  public void login() {
	  System.setProperty("webdriver.chrome.driver","D:\\selenium\\drivers\\Chromedriver_103\\chromedriver_win32\\chromedriver.exe" );
	  ChromeDriver driver=new ChromeDriver();
	  driver.get("https://letcode.in/signin");
	  driver.manage().window().maximize();
	  
	 WebElement email= driver.findElementByName("email");
	 email.sendKeys("jeniferjayaraj12345@gmail.com");
	  
	 WebElement password=driver.findElementByName("password");
	 password.sendKeys("");
  }
}
