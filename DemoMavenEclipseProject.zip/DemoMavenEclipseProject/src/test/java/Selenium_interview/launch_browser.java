package Selenium_interview;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class launch_browser {
WebDriver driver;
	public static void main(String[] args) {
		/*
		 * System.setProperty("webdriver.chrome.driver",
		 * "D:\\selenium\\chromedriver_win32_101 Version\\chromedriver.exe");
		 * ChromeDriver driver= new ChromeDriver();
		 * 
		 * driver.get("https://watchrepairco.com");
		 * 
		 * String currenturl=driver.getCurrentUrl();
		 * System.out.println("Current URL :"+currenturl);
		 * 
		 * String sourcepage=driver.getPageSource(); System.out.println("Page Source "
		 * +sourcepage);
		 * 
		 * String title=driver.getTitle(); System.out.println("Current Title :"+title);
		 * driver.close();
		 */
		/*
		 * System.setProperty("webdriver.gecko.driver",
		 * "D:\\selenium\\geckodriver-v0.31.0-win64\\geckodriver.exe"); FirefoxDriver
		 * driver=new FirefoxDriver(); driver.get("https://watchrepairco.com");
		 * 
		 * String currenturl=driver.getCurrentUrl();
		 * System.out.println("Current URL :"+currenturl);
		 * 
		 * String title=driver.getTitle(); System.out.println("Current Title :"+title);
		 * driver.close();
		 */
       
			 
		System.setProperty("webdriver.edge.driver", "D:\\selenium\\edgedriver_win64\\msedgedriver.exe");
		EdgeDriver driver=new EdgeDriver(); 
		String currenturl=driver.getCurrentUrl();
			  System.out.println("Current URL :"+currenturl);
			  
			  String title=driver.getTitle(); System.out.println("Current Title :"+title);
				 driver.close();
	}

}
